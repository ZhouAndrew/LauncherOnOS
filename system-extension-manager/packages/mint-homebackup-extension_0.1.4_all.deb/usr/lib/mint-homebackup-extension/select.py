#!/usr/bin/env python3
"""Select at most three latest daily mint-* Borg 1.x archives."""
import json
import re
import sys
from datetime import date

PATTERN = re.compile(r"mint-[0-9]{8}T[0-9]{6}Z\Z")


def select(data):
    entries = data.get("archives")
    if not isinstance(entries, list):
        raise ValueError("Borg JSON missing archives array")
    candidates = []
    for a in entries:
        name = a.get("name")
        if not isinstance(name, str):
            raise ValueError("Borg archive missing name")
        if not name.startswith("mint-"):
            continue
        if not PATTERN.fullmatch(name):
            raise ValueError("Unexpected mint-* archive name; refuse deletion: " + name)
        start = a.get("start")
        if not isinstance(start, str) or len(start) < 10:
            raise ValueError("Missing start time for " + name)
        # Borg 1.x uses local-time ISO timestamps in --json 'start'.
        day = date.fromisoformat(start[:10])
        candidates.append((name, day))
    if len({name for name, _ in candidates}) != len(candidates):
        raise ValueError("Duplicate archive name")
    # UTC YYYYMMDDTHHMMSSZ names sort chronologically, newest first.
    candidates.sort(reverse=True)
    selected_dates = set()
    keep = set()
    for name, day in candidates:
        if day not in selected_dates and len(selected_dates) < 3:
            selected_dates.add(day)
            keep.add(name)
    return [name for name, _ in candidates if name in keep], [name for name, _ in candidates if name not in keep]


def main():
    with open(sys.argv[1], encoding="utf-8") as f:
        keep, delete = select(json.load(f))
    for name in keep:
        print("KEEP " + name)
    for name in delete:
        print("DELETE " + name)
    print("保留 %d 份，计划删除 %d 份（仅 mint-* 归档）。" % (len(keep), len(delete)), file=sys.stderr)

if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, TypeError) as exc:
        print("保留策略解析失败，拒绝删除：" + str(exc), file=sys.stderr)
        sys.exit(1)
